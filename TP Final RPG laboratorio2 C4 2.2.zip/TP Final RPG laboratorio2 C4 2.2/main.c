#include <stdio.h>
#include <stdlib.h>
#include "jugar.h"
#include "usuarios.h"
/***
�: 160
�: 130
�: 161
�: 162
�: 163
�: 181
�: 144
�: 214
�: 224
�: 23
�: 164
�: 165
*/


int main()
{
    srand(time(NULL));  /// planto semilla para los dados.
    iniciarPrograma();

    return 0;

}
